int main()
{
#ifndef A
#endif
    return 0;
}
