#include <stdio.h>
int main()
{
    char str[5];
    strcpy(str, "0123456789abcdef");
    return 0;
}
